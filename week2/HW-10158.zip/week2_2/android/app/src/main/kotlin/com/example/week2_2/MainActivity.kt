package com.example.week2_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
