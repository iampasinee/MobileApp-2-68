package com.example.week3_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
